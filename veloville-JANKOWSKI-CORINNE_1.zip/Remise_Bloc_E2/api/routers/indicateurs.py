"""Routeur indicateurs.

À compléter : GET /indicateurs/activite-par-jour,
GET /indicateurs/stations-actives et
GET /indicateurs/incidents-par-statut.
"""
from fastapi import APIRouter
from fastapi import Depends

from sqlalchemy.orm import Session

from datetime import date

from api.database import get_db
from api.services.indicateurs import (
    activite_par_jour,
    stations_actives,
    incidents_par_statut,
)
from api.securite import utilisateur_courant


router = APIRouter(
    prefix="/indicateurs",
    tags=["indicateurs"],
    dependencies=[
            Depends(utilisateur_courant)
        ],
)


@router.get(
    "/activite-par-jour"
)
def lire_activite_par_jour(
    date_debut: date | None = None,
    date_fin: date | None = None,
    db: Session = Depends(get_db),
):
    return activite_par_jour(
        db, 
        date_debut=date_debut, 
        date_fin=date_fin
    )

# @router.get(
#     "/activite-par-jour"
# )
# def lire_activite_par_jour(
#     db: Session = Depends(get_db),
# ):
#     return [
#         {
#             "jour": "2026-08-24",
#             "nb_trajets": 123
#         }
#     ]

@router.get(
    "/stations-actives"
)
def lire_stations_actives(
    limite: int = 10,
    db: Session = Depends(get_db),
):
    return stations_actives(
        db, 
        limite=limite
    )


@router.get(
    "/incidents-par-statut"
)
def lire_incidents_par_statut(
    db: Session = Depends(get_db),
):
    return incidents_par_statut(db)